# HSV Threshold Calibrator

Python tool for calibrating HSV thresholds for use with OpenCV

# Usage:

- This script uses images in .jpg format, so in order to calibrate for an object, take a picture of it, drop it in the resources directory with the title image.jpg.
- Open your terminal prompt at the root of the repo.
- Run "activate" command to start the VENV.
- Run command "python3 main.py" to start the program.
- When finished, run "deactivate" command to stop the VENV.





--Alessandro Bonecchi